import React from 'react'
import './Login.css'

const Loginform = () => {
  return (
        <form>
        <h2>Log in</h2>
        <section>
            <label>Email Address</label>
            <input type="email" placeholder='Example@gmail.com'/>
        </section>
        <section>
            <label>password</label>
            <input type="password" />
            <label className='Forgot'>Forgot password ?</label>
        </section>
        <button>Sign up</button>
        <footer>
            <span>Do not have an account? <h4>Signup</h4></span>
        </footer>

    </form>
  
  )
}

export default Loginform