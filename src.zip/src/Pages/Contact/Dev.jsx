import React from 'react'
import './Contact.css'

const Dev = () => {
  return (
    <div className='Dev'>
        <div className="DevHeader">
            <h2>Quick Contact</h2>
                <span>+2349029523034</span>
                <span>asemudaraglory@gmail.com</span>
        </div>
        <hr />
        <div className="keyContact">
            <h2>KEy contact</h2>
            <section>
                <div className="profile"></div>
                <span>Name</span>
            </section>
            <section>
                <div className="profile"></div>
                <span>Name</span>
            </section>
        </div>
        <hr />
        <div className="Address">
        <h2>Address</h2>

        </div>
    </div>
  )
}

export default Dev